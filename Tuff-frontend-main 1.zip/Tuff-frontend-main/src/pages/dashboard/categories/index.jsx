import { Button, Modal } from 'flowbite-react';
import { useState } from 'react';
import TicketGenerateIcon from '../../../commons/icons/ticketGenerateIcon';
const Category = () => {
    const [openModal, setOpenModal] = useState(false);


    return (
        <div className="h-full p-4 sm:ml-64 bg-gray-50">

            <div className="p-4 space-y-2 mt-14">
                <p className="heading">Operation Categories</p>
                <p className="sub-heading">Sub Heading Goes Here</p>
            </div>

            <div className="grid grid-cols-1 gap-4 mt-4 lg:grid-cols-3 xl:grid-cols-5 md:grid-cols-2 sm:grid-cols-1 ">
                <div onClick={() => setOpenModal(true)} className="p-4 bg-white cursor-pointer rounded-xl">
                    <div className="flex items-center justify-between ">
                        <div className="space-y-3">
                            <p className="text-gray">Total Improvement Request</p>
                            <p className="price">1,689</p>
                        </div>
                    </div>
                </div>

                <div onClick={() => setOpenModal(true)} className="p-4 bg-white cursor-pointer rounded-xl">
                    <div className="flex items-center justify-between ">
                        <div className="space-y-3">
                            <p className="text-gray">Total Improvement Request</p>
                            <p className="price">1,689</p>
                        </div>
                    </div>
                </div>
                <div className="p-4 bg-white rounded-xl">
                    <div className="flex items-center justify-between ">
                        <div className="space-y-3">
                            <p className="text-gray">Total Improvement Request</p>
                            <p className="price">1,689</p>
                        </div>
                    </div>
                </div>
                <div className="p-4 bg-white rounded-xl">
                    <div className="flex items-center justify-between ">
                        <div className="space-y-3">
                            <p className="text-gray">Total Improvement Request</p>
                            <p className="price">1,689</p>
                        </div>
                    </div>
                </div>
                <div className="p-4 bg-white rounded-xl">
                    <div className="flex items-center justify-between ">
                        <div className="space-y-3">
                            <p className="text-gray">Total Improvement Request</p>
                            <p className="price">1,689</p>
                        </div>
                    </div>
                </div>
                <div className="p-4 bg-white rounded-xl">
                    <div className="flex items-center justify-between ">
                        <div className="space-y-3">
                            <p className="text-gray">Total Improvement Request</p>
                            <p className="price">1,689</p>
                        </div>
                    </div>
                </div>
              

            </div>

            <div className="p-4 space-y-2 mt-14">
                <p className="heading">Other Categories</p>
                <p className="sub-heading">Sub Heading Goes Here</p>
            </div>
            <div className="grid grid-cols-1 gap-4 mt-4 lg:grid-cols-3 xl:grid-cols-5 md:grid-cols-2 sm:grid-cols-1 ">
                <div className="p-4 bg-white rounded-xl">
                    <div className="flex items-center justify-between ">
                        <div className="space-y-3">
                            <p className="text-gray">Total Improvement Request</p>
                            <p className="price">1,689</p>
                        </div>
                    </div>
                </div>

                <div className="p-4 bg-white rounded-xl">
                    <div className="flex items-center justify-between ">
                        <div className="space-y-3">
                            <p className="text-gray">Total Improvement Request</p>
                            <p className="price">1,689</p>
                        </div>
                    </div>
                </div>
                <div className="p-4 bg-white rounded-xl">
                    <div className="flex items-center justify-between ">
                        <div className="space-y-3">
                            <p className="text-gray">Total Improvement Request</p>
                            <p className="price">1,689</p>
                        </div>
                    </div>
                </div>
                <div className="p-4 bg-white rounded-xl">
                    <div className="flex items-center justify-between ">
                        <div className="space-y-3">
                            <p className="text-gray">Total Improvement Request</p>
                            <p className="price">1,689</p>
                        </div>
                    </div>
                </div>
                <div className="p-4 bg-white rounded-xl">
                    <div className="flex items-center justify-between ">
                        <div className="space-y-3">
                            <p className="text-gray">Total Improvement Request</p>
                            <p className="price">1,689</p>
                        </div>
                    </div>
                </div>
                <div className="p-4 bg-white rounded-xl">
                    <div className="flex items-center justify-between ">
                        <div className="space-y-3">
                            <p className="text-gray">Total Improvement Request</p>
                            <p className="price">1,689</p>
                        </div>
                    </div>
                </div>


            </div>
            <Modal dismissible style={{ zIndex: 1000 }} show={openModal} size="md" onClose={() => setOpenModal(false)} popup>
                {/* <Modal.Header /> */}
                <Modal.Body className="p-8">
                    <div className="flex flex-col items-center justify-center space-y-2 text-center ">
                        <p className='orange-alert' style={{ fontSize:'20px' }}>Category Name Here</p>
                        <img src="https://s3-alpha-sig.figma.com/img/5663/b367/389f320791ab557401e049ffbc75a559?Expires=1710115200&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=pzHO0faFGf3lbA6DbIDusclzgoavAKhA~4QxPNBPRg3tD-ZYP314LTyE-RFIUuLdHtodeMx2mt5fBSDgyizDjtkG6hV0VR97TgknGjTzjl4v0ZkG1DrBorlTkFvjQKPuuixmf2sG7m692gV3ExHH0-MhC5MlnWdMR0k3asU8te-lUGzoAEuL1vcKHfhPl3OCFk2-5N7Tq9QrRYQNb8AYWxeMN3cRkeaMk5IWFPLAx4M144iSfGJzs57Xi7y92b2sEaPaWXIgmpbKjHsBLFXbhhsiIA-LgjDMKTV-MCIohfoxdt3CQ1KU63~4rPH4uy8aqDMrMZ6N3TS7-s9wgR2UZA__" alt="" />
                        <button className="flex ticket-button-fill">
                            <p> Share this QR</p>
                           
                            <svg width="25" height="24" viewBox="0 0 25 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M16.6391 2.95998L7.60914 5.95998C1.53914 7.98998 1.53914 11.3 7.60914 13.32L10.2891 14.21L11.1791 16.89C13.1991 22.96 16.5191 22.96 18.5391 16.89L21.5491 7.86998C22.8891 3.81998 20.6891 1.60998 16.6391 2.95998ZM16.9591 8.33998L13.1591 12.16C13.0091 12.31 12.8191 12.38 12.6291 12.38C12.4391 12.38 12.2491 12.31 12.0991 12.16C11.8091 11.87 11.8091 11.39 12.0991 11.1L15.8991 7.27998C16.1891 6.98998 16.6691 6.98998 16.9591 7.27998C17.2491 7.56998 17.2491 8.04998 16.9591 8.33998Z" fill="white" />
                            </svg>
                        </button>

                    </div>
                </Modal.Body>
            </Modal>
            
        </div>
    );
}
export default Category;