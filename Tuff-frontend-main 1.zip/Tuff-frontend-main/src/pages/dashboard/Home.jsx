const Home = () => {
    return (
        <div className="h-full p-4 sm:ml-64 bg-gray-50">
           
            <div className="p-4 mt-14">
                <div className="admin-text">
                    <p >Good Morning!</p>
                    <p >Admin</p>
                </div>
              
                <div className="grid grid-cols-1 gap-4 mt-4 lg:grid-cols-3 xl:grid-cols-5 md:grid-cols-2 sm:grid-cols-1 ">
                    <div className="p-4 bg-white rounded-xl">
                        <div className="flex items-center justify-between ">
                            <div className="space-y-3">
                                <p className="text-gray">Total Improvement Request</p>
                                <p className="price">1,689</p>
                            </div>
                            <div style={{ backgroundColor:'rgb(213, 230, 255)' }} className="p-2 rounded-md">
                                <svg width="44" height="44" viewBox="0 0 44 44" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M24.1077 28.1784C23.7043 27.5918 22.9893 27.2618 22.1644 27.2618H17.8927C17.6177 27.2618 17.3427 27.1518 17.1777 26.9318C16.9943 26.7118 16.921 26.4368 16.9577 26.1251L17.4893 22.7151C17.7093 21.7068 17.031 20.5518 16.0227 20.2034C15.0693 19.8551 13.9693 20.3318 13.511 21.0101L9.27602 27.3168V26.5284C9.27602 24.9884 8.61602 24.3651 7.00268 24.3651H5.93935C4.32602 24.3834 3.66602 25.0068 3.66602 26.5468V37.0151C3.66602 38.5551 4.32602 39.1784 5.93935 39.1784H7.00268C8.54268 39.1784 9.18435 38.5734 9.23935 37.1801L12.4477 39.6551C12.906 40.0951 13.8777 40.3334 14.5743 40.3334H18.626C20.0193 40.3334 21.4127 39.2884 21.7427 38.0051L24.3093 30.2134C24.5844 29.4618 24.511 28.7468 24.1077 28.1784Z" fill="#8280FF" />
                                    <path d="M38.7014 4.78488H37.6381C36.0981 4.78488 35.4564 5.38988 35.3831 6.78322L32.1748 4.30822C31.7348 3.86822 30.7448 3.62988 30.0481 3.62988H25.9964C24.6031 3.62988 23.2098 4.67488 22.8798 5.95822L20.3131 13.7499C20.0381 14.5015 20.1298 15.2165 20.5148 15.7849C20.9181 16.3715 21.6331 16.7015 22.4581 16.7015H26.7298C27.0048 16.7015 27.2798 16.8116 27.4448 17.0315C27.6281 17.2515 27.7014 17.5265 27.6648 17.8382L27.1331 21.2482C26.9131 22.2566 27.5914 23.4115 28.5998 23.7599C29.5531 24.1082 30.6531 23.6316 31.1114 22.9532L35.3464 16.6465V17.4349C35.3464 18.9749 36.0064 19.5982 37.6198 19.5982H38.6831C40.2964 19.5982 40.9564 18.9749 40.9564 17.4349V6.92988C40.9748 5.40822 40.3148 4.78488 38.7014 4.78488Z" fill="#8280FF" />
                                </svg>

                            </div>
                        </div>
                        <div className="flex items-center mt-3 space-x-2">
                            <svg width="20" height="12" viewBox="0 0 20 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M14 0L16.29 2.29L11.41 7.17L7.41 3.17L0 10.59L1.41 12L7.41 6L11.41 10L17.71 3.71L20 6V0H14Z" fill="#00B69B" />
                            </svg>
                            <p>8.5%</p>
                            <p className="text-gray">Up from last week</p>
                        </div>
                    </div>
                    <div className="p-4 bg-white rounded-xl">
                        <div className="flex items-center justify-between ">
                            <div className="space-y-3">
                                <p className="text-gray">Total Improved Request</p>
                                <p className="price">1,689</p>
                            </div>
                            <div style={{ backgroundColor: "rgb(255, 243, 180)" }} className="p-2 rounded-md ">
                                <svg width="44" height="44" viewBox="0 0 44 44" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M15.3809 33.8983V15.2717C15.3809 14.5383 15.6009 13.8233 16.0042 13.2183L21.0092 5.775C21.7975 4.58333 23.7592 3.74 25.4275 4.36333C27.2242 4.96833 28.4159 6.98499 28.0309 8.78166L27.0775 14.7767C27.0042 15.3267 27.1509 15.8217 27.4625 16.2067C27.7742 16.555 28.2325 16.775 28.7275 16.775H36.2625C37.7109 16.775 38.9575 17.3617 39.6909 18.3883C40.3875 19.3783 40.5159 20.6617 40.0575 21.9633L35.5475 35.695C34.9792 37.9683 32.5042 39.82 30.0475 39.82H22.8975C21.6692 39.82 19.9459 39.3983 19.1575 38.61L16.8109 36.795C15.9125 36.1167 15.3809 35.035 15.3809 33.8983Z" fill="#FEC53D" />
                                    <path d="M9.55102 11.6968H7.66268C4.82102 11.6968 3.66602 12.7968 3.66602 15.5101V33.9534C3.66602 36.6668 4.82102 37.7668 7.66268 37.7668H9.55102C12.3927 37.7668 13.5477 36.6668 13.5477 33.9534V15.5101C13.5477 12.7968 12.3927 11.6968 9.55102 11.6968Z" fill="#FEC53D" />
                                </svg>


                            </div>
                        </div>
                        <div className="flex items-center mt-3 space-x-2">
                            <svg width="20" height="12" viewBox="0 0 20 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M14 12L16.29 9.71L11.41 4.83L7.41 8.83L0 1.41L1.41 0L7.41 6L11.41 2L17.71 8.29L20 6V12H14Z" fill="#F93C65" />
                            </svg>

                            <p>8.5%</p>
                            <p className="text-gray">Up from last week</p>
                        </div>
                    </div>
                    <div className="p-4 bg-white rounded-xl">
                        <div className="flex items-center justify-between ">
                            <div className="space-y-3">
                                <p className="text-gray">Total Tickets Converted</p>
                                <p className="price">1,689</p>
                            </div>
                            <div style={{ backgroundColor:'rgb(195, 255 ,217)' }} className="p-2 rounded-md ">
                                <svg width="44" height="44" viewBox="0 0 44 44" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M21.9993 33.9167V35.53C21.9993 38.9583 20.6243 40.3333 17.1777 40.3333H8.46935C5.81102 40.3333 3.66602 38.1883 3.66602 35.53V26.8217C3.66602 23.375 5.04102 22 8.46935 22H10.0827V28.4167C10.0827 31.46 12.5393 33.9167 15.5827 33.9167H21.9993Z" fill="#4AD991" />
                                    <path d="M31.1673 24.7499V26.3449C31.1673 29.0033 29.004 31.1666 26.3457 31.1666H17.6373C14.209 31.1666 12.834 29.7916 12.834 26.3449V17.6366C12.834 14.9783 14.979 12.8333 17.6373 12.8333H19.2507V19.2499C19.2507 22.2933 21.7073 24.7499 24.7507 24.7499H31.1673Z" fill="#4AD991" />
                                    <path d="M40.3333 8.47008V17.1784C40.3333 20.6251 38.9583 22.0001 35.5117 22.0001H26.8033C23.375 22.0001 22 20.6251 22 17.1784V8.47008C22 5.04175 23.375 3.66675 26.8033 3.66675H35.5117C38.9583 3.66675 40.3333 5.04175 40.3333 8.47008Z" fill="#4AD991" />
                                </svg>


                            </div>
                        </div>
                        <div className="flex items-center mt-3 space-x-2">
                            <svg width="20" height="12" viewBox="0 0 20 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M14 0L16.29 2.29L11.41 7.17L7.41 3.17L0 10.59L1.41 12L7.41 6L11.41 10L17.71 3.71L20 6V0H14Z" fill="#00B69B" />
                            </svg>

                            <p>8.5%</p>
                            <p className="text-gray">Up from last week</p>
                        </div>
                    </div>
                    <div className="p-4 bg-white rounded-xl">
                        <div className="flex items-center justify-between ">
                            <div className="space-y-3">
                                <p className="text-gray">Total Improvement Request</p>
                                <p className="price">1,689</p>
                            </div>
                            <div style={{ backgroundColor:'rgb(255 205 186)'}} className="p-2 rounded-md ">
                                <svg width="44" height="44" viewBox="0 0 44 44" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M22.0005 8.5249C13.2371 8.5249 6.10547 15.6566 6.10547 24.4199C6.10547 33.1832 13.2371 40.3332 22.0005 40.3332C30.7638 40.3332 37.8955 33.2016 37.8955 24.4382C37.8955 15.6749 30.7638 8.5249 22.0005 8.5249ZM23.3755 23.8332C23.3755 24.5849 22.7521 25.2082 22.0005 25.2082C21.2488 25.2082 20.6255 24.5849 20.6255 23.8332V14.6666C20.6255 13.9149 21.2488 13.2916 22.0005 13.2916C22.7521 13.2916 23.3755 13.9149 23.3755 14.6666V23.8332Z" fill="#FF9871" />
                                    <path d="M27.2975 6.32508H16.7009C15.9675 6.32508 15.3809 5.73841 15.3809 5.00508C15.3809 4.27175 15.9675 3.66675 16.7009 3.66675H27.2975C28.0309 3.66675 28.6175 4.25341 28.6175 4.98675C28.6175 5.72008 28.0309 6.32508 27.2975 6.32508Z" fill="#FF9871" />
                                </svg>


                            </div>
                        </div>
                        <div className="flex items-center mt-3 space-x-2">
                            <svg width="20" height="12" viewBox="0 0 20 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M14 0L16.29 2.29L11.41 7.17L7.41 3.17L0 10.59L1.41 12L7.41 6L11.41 10L17.71 3.71L20 6V0H14Z" fill="#00B69B" />
                            </svg>
                            <p>8.5%</p>
                            <p className="text-gray">Up from last week</p>
                        </div>
                    </div>
               
                </div>

            </div>
        </div>)
}
export default Home