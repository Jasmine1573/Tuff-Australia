import { useState, useEffect } from "react";
import { Outlet } from "react-router-dom";
import Sidebar from "../../layouts/SideBar";
const Dashboard = () => {
    return (
        <div className="bg-gray-50">
            <Sidebar/>
            <Outlet />
        </div>
    )
}
export default Dashboard;