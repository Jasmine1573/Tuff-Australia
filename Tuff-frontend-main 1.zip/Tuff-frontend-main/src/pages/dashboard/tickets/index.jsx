import Pagination from "../../../commons/pagination"
import { Button, Modal } from 'flowbite-react';
import { useState } from 'react';
const Ticket = () => {
    const [openModal, setOpenModal] = useState(false);


    return (
        <div className="h-full p-4 sm:ml-64 bg-gray-50">

            <div className="p-4 space-y-2 mt-14">
                <p className="heading">Tickets</p>
            </div>



            <div className="relative overflow-x-auto shadow-md sm:rounded-lg">
                <table className="w-full text-left text-gray-500 text-md rtl:text-right ">
                    <thead className="text-[#202224] bg-white text-md ">
                        <tr>
                            <th scope="col" className="px-3 py-3">
                                ID
                            </th>
                            <th scope="col" className="px-3 py-3">
                                Customer
                            </th>
                            <th scope="col" className="px-3 py-3">
                                Category
                            </th>
                            <th scope="col" className="px-3 py-3">
                                Date
                            </th>
                            <th scope="col" className="px-3 py-3">
                                Message
                            </th>
                            <th scope="col" className="px-3 py-3">
                                Status
                            </th>
                            <th scope="col" className="px-3 py-3">
                            </th>
                        </tr>
                    </thead>
                    <tbody>

                        <tr className="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
                            <th scope="row" className="px-3 py-4 font-medium whitespace-nowrap sub-heading">
                                10009
                            </th>
                            <td className="flex px-3 py-4 space-x-2">
                                <div>
                                    <svg width="45" height="45" viewBox="0 0 45 45" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <circle cx="22.5" cy="22.5" r="22.5" fill="#808080" />
                                    </svg>

                                </div>
                                <div>
                                    <p className="table-item">
                                        John Adams
                                    </p>
                                    <p>
                                        johnadams@gmail.com
                                    </p>
                                </div>
                            </td>
                            <td className="px-3 py-4 sub-heading">
                                Category Name Here
                            </td>
                            <td className="px-3 py-4 sub-heading">
                                04 Sep 2019
                            </td>
                            <td className="px-3 py-4 sub-heading">
                                Lorem ipsum dolor sit....
                            </td>
                            <td className="px-3 py-4 ">
                                <p className="status processing" >Processing</p>
                            </td>
                            <td className="px-3 py-4 sub-heading">
                                <button onClick={() => setOpenModal(true)} style={{ color: '#E65526' }} className="">
                                    edit status
                                </button>
                            </td>

                        </tr>
                        <tr className="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
                            <th scope="row" className="px-3 py-4 font-medium whitespace-nowrap sub-heading">
                                10009
                            </th>
                            <td className="flex px-3 py-4 space-x-2">
                                <div>
                                    <svg width="45" height="45" viewBox="0 0 45 45" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <circle cx="22.5" cy="22.5" r="22.5" fill="#808080" />
                                    </svg>

                                </div>
                                <div>
                                    <p className="table-item">
                                        John Adams
                                    </p>
                                    <p>
                                        johnadams@gmail.com
                                    </p>
                                </div>
                            </td>
                            <td className="px-3 py-4 sub-heading">
                                Category Name Here
                            </td>
                            <td className="px-3 py-4 sub-heading">
                                04 Sep 2019
                            </td>
                            <td className="px-3 py-4 sub-heading">
                                Lorem ipsum dolor sit....
                            </td>
                            <td className="px-3 py-4 ">
                                <p className="status completed" >Completed</p>
                            </td>
                            <td className="px-3 py-4 sub-heading">
                                <button onClick={() => setOpenModal(true)} style={{ color: '#E65526' }} className="">
                                    edit status
                                </button>
                            </td>

                        </tr>
                        <tr className="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
                            <th scope="row" className="px-3 py-4 font-medium whitespace-nowrap sub-heading">
                                10009
                            </th>
                            <td className="flex px-3 py-4 space-x-2">
                                <div>
                                    <svg width="45" height="45" viewBox="0 0 45 45" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <circle cx="22.5" cy="22.5" r="22.5" fill="#808080" />
                                    </svg>

                                </div>
                                <div>
                                    <p className="table-item">
                                        John Adams
                                    </p>
                                    <p>
                                        johnadams@gmail.com
                                    </p>
                                </div>
                            </td>
                            <td className="px-3 py-4 sub-heading">
                                Category Name Here
                            </td>
                            <td className="px-3 py-4 sub-heading">
                                04 Sep 2019
                            </td>
                            <td className="px-3 py-4 sub-heading">
                                Lorem ipsum dolor sit....
                            </td>
                            <td className="px-3 py-4 ">
                                <p className="status rejected" >Rejected</p>
                            </td>
                            <td className="px-3 py-4 sub-heading">
                                <button onClick={() => setOpenModal(true)} style={{ color: '#E65526' }} className="">
                                    edit status
                                </button>
                            </td>

                        </tr>
                        <tr className="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
                            <th scope="row" className="px-3 py-4 font-medium whitespace-nowrap sub-heading">
                                10009
                            </th>
                            <td className="flex px-3 py-4 space-x-2">
                                <div>
                                    <svg width="45" height="45" viewBox="0 0 45 45" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <circle cx="22.5" cy="22.5" r="22.5" fill="#808080" />
                                    </svg>

                                </div>
                                <div>
                                    <p className="table-item">
                                        John Adams
                                    </p>
                                    <p>
                                        johnadams@gmail.com
                                    </p>
                                </div>
                            </td>
                            <td className="px-3 py-4 sub-heading">
                                Category Name Here
                            </td>
                            <td className="px-3 py-4 sub-heading">
                                04 Sep 2019
                            </td>
                            <td className="px-3 py-4 sub-heading">
                                Lorem ipsum dolor sit....
                            </td>
                            <td className="px-3 py-4 ">
                                <p className="status onhold" >On Hold</p>
                            </td>
                            <td className="px-3 py-4 sub-heading">
                                <button onClick={() => setOpenModal(true)} style={{ color: '#E65526' }} className="">
                                    edit status
                                </button>
                            </td>

                        </tr>







                    </tbody>
                </table>
            </div>




            <Pagination />

            <Modal dismissible style={{ zIndex: 1000 }} show={openModal} size="md" onClose={() => setOpenModal(false)} popup>
                {/* <Modal.Header /> */}
                <Modal.Body className="p-6">
                    <div className="space-y-2 ">
                        <div className="flex justify-between space-y-2">
                            <div className="space-y-5">
                                <div className="">
                                    <p>ID</p>
                                    <p>1000</p>
                                </div>
                                <div className="">
                                    <p>Customer</p>
                                    <p>Name</p>
                                </div>
                            </div>
                            <div className="space-y-5">
                                <div className="">
                                    <p>ID</p>
                                    <p>1000</p>
                                </div>
                                <div className="">
                                    <p>Customer</p>
                                    <p>Name</p>
                                </div>
                            </div>
                            <div className="space-y-5">
                                <div className="">
                                    <p>ID</p>
                                    <p>1000</p>
                                </div>
                             
                            </div>
                        </div>
                        <div>
                            <p>Date</p>
                            <p>2022-2-2</p>
                        </div>

                        <div>
                            <p></p>
                        </div>
                      
                    </div>
                </Modal.Body>
            </Modal>
        </div>
    )
}
export default Ticket