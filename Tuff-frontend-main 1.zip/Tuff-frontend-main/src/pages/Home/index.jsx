import Header from "../../layouts/Header";
import { Outlet } from "react-router-dom";
import Footer from "../../layouts/Footer";
const UserHome = () => {
    return (

        <div className="bg-gray-50">
            <Header />
            <div style={{ marginTop: '137px' }}>
                <Outlet />
                <Footer />
            </div>
        </div>
    );
}
export default UserHome;