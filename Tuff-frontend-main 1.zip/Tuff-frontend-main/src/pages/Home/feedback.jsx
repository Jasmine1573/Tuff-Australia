import { Button, Modal } from 'flowbite-react';
import { useState } from 'react';
import TicketGenerateIcon from "../../commons/icons/ticketGenerateIcon";


const UserFeedback = () => {
    const [openModal, setOpenModal] = useState(false);

    return (
        <div>
            <div className="p-16 w-ful feedback-img-div">
                <div>
                    <h1 className="text-white text-title"> Give your   </h1>
                    <h1 className="text-title text-orange"> Improvement   </h1>
                    <h1 className="text-white text-title"> Feedbacks   </h1>
                </div>
            </div>
            <div className="grid grid-cols-1 md:grid-col-1 lg:grid-cols-2 xl:grid-cols-2 gap-[52px] feedback-form-outer">
                <div>
                    <h1 className='feedback-heading'>DISCOVER US</h1>
                    <p className="mt-6 feedback-content">Simple, honest and transparent pricing is a priority for TUFF. Our products are not the cheapest on the market, but they definitely give the most bang for your buck. <span> <a href="" className='underline text-orange'> visit our page</a></span></p>
                    <h1 className="mt-8 uppercase feedback-heading">Opening Hours </h1>
                    <div className="flex items-center justify-between mt-5 space-y-2 " style={{ width: '75%' }}>
                        <div className="space-y-2 feedback-subheading">
                            <p>Monday to Friday:</p>
                            <p>Saturday & Sunday:</p>
                        </div>
                        <div className="space-y-2 feedback-content">
                            <p> 7:30 AM - 5:00 PM</p>
                            <p>Closed</p>
                        </div>
                    </div>
                    <p className="mt-5 feedback-content">Feel free to get in touch with us through our channels:</p>
                    <h1 className="mt-5 uppercase feedback-heading">Email US</h1>
                    <p className="feedback-conten text-orange">feedback@tuffaustralia.com.au</p>
                    <div className="mt-5">
                        <h1 className="uppercase feedback-heading">Follow Us</h1>
                        <div className="flex items-center mt-3 space-x-5">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M24 12C24 5.37258 18.6274 0 12 0C5.37258 0 0 5.37258 0 12C0 17.9895 4.3882 22.954 10.125 23.8542V15.4688H7.07812V12H10.125V9.35625C10.125 6.34875 11.9166 4.6875 14.6576 4.6875C15.9701 4.6875 17.3438 4.92188 17.3438 4.92188V7.875H15.8306C14.34 7.875 13.875 8.80008 13.875 9.75V12H17.2031L16.6711 15.4688H13.875V23.8542C19.6118 22.954 24 17.9895 24 12Z" fill="#808080" />
                            </svg>

                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <g clip-path="url(#clip0_61_2054)">
                                    <path d="M12 2.16094C15.2063 2.16094 15.5859 2.175 16.8469 2.23125C18.0188 2.28281 18.6516 2.47969 19.0734 2.64375C19.6313 2.85938 20.0344 3.12188 20.4516 3.53906C20.8734 3.96094 21.1313 4.35938 21.3469 4.91719C21.5109 5.33906 21.7078 5.97656 21.7594 7.14375C21.8156 8.40937 21.8297 8.78906 21.8297 11.9906C21.8297 15.1969 21.8156 15.5766 21.7594 16.8375C21.7078 18.0094 21.5109 18.6422 21.3469 19.0641C21.1313 19.6219 20.8687 20.025 20.4516 20.4422C20.0297 20.8641 19.6313 21.1219 19.0734 21.3375C18.6516 21.5016 18.0141 21.6984 16.8469 21.75C15.5813 21.8062 15.2016 21.8203 12 21.8203C8.79375 21.8203 8.41406 21.8062 7.15313 21.75C5.98125 21.6984 5.34844 21.5016 4.92656 21.3375C4.36875 21.1219 3.96563 20.8594 3.54844 20.4422C3.12656 20.0203 2.86875 19.6219 2.65313 19.0641C2.48906 18.6422 2.29219 18.0047 2.24063 16.8375C2.18438 15.5719 2.17031 15.1922 2.17031 11.9906C2.17031 8.78438 2.18438 8.40469 2.24063 7.14375C2.29219 5.97187 2.48906 5.33906 2.65313 4.91719C2.86875 4.35938 3.13125 3.95625 3.54844 3.53906C3.97031 3.11719 4.36875 2.85938 4.92656 2.64375C5.34844 2.47969 5.98594 2.28281 7.15313 2.23125C8.41406 2.175 8.79375 2.16094 12 2.16094ZM12 0C8.74219 0 8.33438 0.0140625 7.05469 0.0703125C5.77969 0.126563 4.90313 0.332812 4.14375 0.628125C3.35156 0.9375 2.68125 1.34531 2.01563 2.01562C1.34531 2.68125 0.9375 3.35156 0.628125 4.13906C0.332812 4.90313 0.126563 5.775 0.0703125 7.05C0.0140625 8.33437 0 8.74219 0 12C0 15.2578 0.0140625 15.6656 0.0703125 16.9453C0.126563 18.2203 0.332812 19.0969 0.628125 19.8563C0.9375 20.6484 1.34531 21.3188 2.01563 21.9844C2.68125 22.65 3.35156 23.0625 4.13906 23.3672C4.90313 23.6625 5.775 23.8687 7.05 23.925C8.32969 23.9812 8.7375 23.9953 11.9953 23.9953C15.2531 23.9953 15.6609 23.9812 16.9406 23.925C18.2156 23.8687 19.0922 23.6625 19.8516 23.3672C20.6391 23.0625 21.3094 22.65 21.975 21.9844C22.6406 21.3188 23.0531 20.6484 23.3578 19.8609C23.6531 19.0969 23.8594 18.225 23.9156 16.95C23.9719 15.6703 23.9859 15.2625 23.9859 12.0047C23.9859 8.74688 23.9719 8.33906 23.9156 7.05938C23.8594 5.78438 23.6531 4.90781 23.3578 4.14844C23.0625 3.35156 22.6547 2.68125 21.9844 2.01562C21.3188 1.35 20.6484 0.9375 19.8609 0.632812C19.0969 0.3375 18.225 0.13125 16.95 0.075C15.6656 0.0140625 15.2578 0 12 0Z" fill="#808080" />
                                    <path d="M12 5.83594C8.59688 5.83594 5.83594 8.59688 5.83594 12C5.83594 15.4031 8.59688 18.1641 12 18.1641C15.4031 18.1641 18.1641 15.4031 18.1641 12C18.1641 8.59688 15.4031 5.83594 12 5.83594ZM12 15.9984C9.79219 15.9984 8.00156 14.2078 8.00156 12C8.00156 9.79219 9.79219 8.00156 12 8.00156C14.2078 8.00156 15.9984 9.79219 15.9984 12C15.9984 14.2078 14.2078 15.9984 12 15.9984Z" fill="#808080" />
                                    <path d="M19.8469 5.59214C19.8469 6.38902 19.2 7.0312 18.4078 7.0312C17.6109 7.0312 16.9688 6.38433 16.9688 5.59214C16.9688 4.79526 17.6156 4.15308 18.4078 4.15308C19.2 4.15308 19.8469 4.79995 19.8469 5.59214Z" fill="#808080" />
                                </g>
                                <defs>
                                    <clipPath id="clip0_61_2054">
                                        <rect width="24" height="24" fill="white" />
                                    </clipPath>
                                </defs>
                            </svg>
                            <img height={20} width={20} src="https://s3-alpha-sig.figma.com/img/f21a/7ec7/54e718b1bb1e473cda01e4dc7b02f661?Expires=1710115200&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=mYv2M7CYSXkrdCNF8CiyK21dGd0lzKhzpMnG0PcAIPACFgeT~LYtcBiflXsWpS8hMDIPyBtoIp-crriqmLIWup2OxmYcxhEqEM~yZ7icQ~NHnw6e2JQ3xa9iY-FpJ~4YY2pm3m4HSRjkaPjtzwQI4Ggbu9kyrkVuRWFw3-jXTASUEbbNlcVp3U8V8hpgNnO2zaWl7JVFz0yNugq6IUPsbAsIKKUSiaprJeoxsHK8zcWepTHUYOaMzrNuF5UJjdRZyCPEmXhRZ0ki96ubM-UgfjHttaD4BTIvjPsPYY79HpxNkDrkO9suuVoKSbhElT3AZHxKXkt-lOnEvL8ijUiHYg__" alt="" />
                            <svg width="20" height="20" viewBox="0 0 24 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M23.7609 4.20005C23.7609 4.20005 23.5266 2.54536 22.8047 1.8188C21.8906 0.862549 20.8688 0.857861 20.4 0.801611C17.0438 0.557861 12.0047 0.557861 12.0047 0.557861H11.9953C11.9953 0.557861 6.95625 0.557861 3.6 0.801611C3.13125 0.857861 2.10938 0.862549 1.19531 1.8188C0.473438 2.54536 0.24375 4.20005 0.24375 4.20005C0.24375 4.20005 0 6.14536 0 8.08599V9.90474C0 11.8454 0.239062 13.7907 0.239062 13.7907C0.239062 13.7907 0.473437 15.4454 1.19062 16.1719C2.10469 17.1282 3.30469 17.0954 3.83906 17.1985C5.76094 17.3813 12 17.4375 12 17.4375C12 17.4375 17.0438 17.4282 20.4 17.1891C20.8688 17.1329 21.8906 17.1282 22.8047 16.1719C23.5266 15.4454 23.7609 13.7907 23.7609 13.7907C23.7609 13.7907 24 11.85 24 9.90474V8.08599C24 6.14536 23.7609 4.20005 23.7609 4.20005ZM9.52031 12.1125V5.36724L16.0031 8.75161L9.52031 12.1125Z" fill="#808080" />
                            </svg>




                        </div>
                    </div>
                </div>
                <div className="space-y-4">
                    <div className="">
                        <label htmlFor="name" className="block mb-2 label">What’s your name?</label>
                        <input type="text" id="name" className="shadow-sm bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg  block w-full p-2.5 " placeholder="Enter your full name" required />
                    </div>
                    <div className="">
                        <label htmlFor="email" className="block mb-2 label">What’s your email?</label>
                        <input type="email" id="email" className="shadow-sm bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg  block w-full p-2.5 " placeholder="Enter your email address" required />
                    </div>
                    <div className="">
                        <label htmlFor="contact" className="block mb-2 label">What’s your contact number?</label>
                        <input type="contact" id="contact" className="shadow-sm bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg  block w-full p-2.5 " placeholder="Enter your contact number" required />
                    </div>
                    <div className="">
                        <label htmlFor="category" className="block mb-2 label">Select your Category?</label>
                        <select id="default" className="bg-gray-50 border border-gray-300 text-gray-900 mb-6 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
                            <option selected>Select your category</option>
                            <option value="Administration">Administration</option>
                            <option value="Sales">Sales</option>
                            <option value="Finance">Finance</option>
                            <option value="Human Resources">Human Resources</option>
                        </select>
                    </div>
                    <div className="">
                        <label htmlFor="contact" className="block mb-2 label">What’s your improvement feedback?</label>
                        <textarea id="message" rows="4" className="block p-2.5 w-full text-sm text-gray-900 bg-gray-50 rounded-lg border border-gray-300 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" placeholder="Enter your message here"></textarea>
                    </div>
                    <div className="mt-3">
                        <label htmlFor="contact" className="block mb-2 label">Image for feedback</label>

                        <label htmlFor="dropzone-file" className="flex flex-col items-center justify-center w-full border-2 border-gray-300 border-dashed rounded-lg cursor-pointer h-28 bg-gray-50 dark:hover:bg-bray-800 dark:bg-gray-700 hover:bg-gray-100 dark:border-gray-600 dark:hover:border-gray-500 dark:hover:bg-gray-600">
                            <div className="flex flex-col items-center justify-center pt-5 pb-6">
                                <svg className="w-8 h-8 mb-4 text-gray-500 dark:text-gray-400" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 20 16">
                                    <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 13h3a3 3 0 0 0 0-6h-.025A5.56 5.56 0 0 0 16 6.5 5.5 5.5 0 0 0 5.207 5.021C5.137 5.017 5.071 5 5 5a4 4 0 0 0 0 8h2.167M10 15V6m0 0L8 8m2-2 2 2" />
                                </svg>
                                <p className="mb-2 text-sm text-gray-500 dark:text-gray-400"><span className="font-semibold">Click to upload</span> or drag and drop</p>
                                {/* <p className="text-xs text-gray-500 dark:text-gray-400">SVG, PNG, JPG or GIF (MAX. 800x400px)</p> */}
                            </div>
                            <input id="dropzone-file" type="file" className="hidden" />
                        </label>
                    </div>
                    <button onClick={() => setOpenModal(true)} className="w-full p-2 mt-8 text-white rounded-full authActive-button poppins_button">Submit Feedback</button>
                    <div className="" style={{ height:'60px' }}>

                    </div>

                </div>

            </div>
            <Modal dismissible style={{ zIndex: 1000 }} show={openModal} size="md" onClose={() => setOpenModal(false)} popup>
                {/* <Modal.Header /> */}
                <Modal.Body className="p-8">
                    <div className="flex flex-col items-center justify-center space-y-2 text-center ">
                        <TicketGenerateIcon />

                        <p className="mt-2 orange-alert">Thank You!</p>
                        <p className="orange-alert">Ticket generated</p>
                        <p className="my-3 text-center alert-message">The feedback improvements are converted to tickets.You can now manage the tickets status and can resolve them. </p>
                        <button className="ticket-button">See Tickets</button>
                    </div>
                </Modal.Body>
            </Modal>
        </div>
    );
}
export default UserFeedback