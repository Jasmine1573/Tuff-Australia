import React, { useState } from 'react';

const Login = () => {
    const [showPassword, setShowPassword] = useState(false);

    const togglePasswordVisibility = () => {
        setShowPassword(!showPassword);
    };

    return (
        <div className="flex items-center justify-center w-full" style={{ marginTop: '-60px' }}>
            <div className="form-div" style={{ width: '100%', maxWidth: '600px', margin: '0 auto' }}>
                <div className="flex flex-col justify-center ">
                    <div className='flex flex-col '>
                        {/* <img className='self-center logo-icon' src="https://s3-alpha-sig.figma.com/img/c221/6f46/f274ab153ecf218b6916f5f4cb8fbf47?Expires=1710115200&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=HrkX4DCIJa17~H4mU7QYanN2jVsJip~D1Hg08j7KVIq04zxXXGnXgxhvis-vVVWNW7ImQHDHa0ClZc~79cFjattyPTJ8N2~Jbr0dPiT7ACTeVT44wEd9nXUlHyVIXnWJFpiNz82SzYiKqQaDvC6qN90nWhVREfR8~aHftLvptx5F1Kh4ql97eKm~HMLMm1rbhwkHW6dHP39ZnGlF2Apc-7Wypp2TqQ1Tfe8MtJNgqMedsqT5ttAqzHlEE2Db34ImhdWyK2YQ7UEPh30U1SF9l8LSuy4p19Msxl92VO9x6WaLZFWCVyQwXh5dBmBkwjLiajmK9MmigDZ5m3VhYxFC3w__" alt="" /> */}
                        <p className='self-center auth-title'>Welcome Back</p>
                        <div className='flex self-center mb-4 space-x-2'>
                            <p className='text-secondary'>New here?  </p>
                            <a className='text-primary' href="">Create Account </a>
                        </div>
                    </div>

                    <div className="mt-3 mb-5 ">
                        <label htmlFor="email" className="block mb-2 label">Email address</label>
                        <input type="email" id="email" className="shadow-sm bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg  block w-full p-2.5 " placeholder="name@flowbite.com" required />
                    </div>


                    <div className="mb-5">
                        <label htmlFor="password" className="block mb-2 label">Your password</label>
                        <div className="relative">
                            <input
                                type={showPassword ? "text" : "password"}
                                id="password"
                                className="shadow-sm bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg  block w-full p-2.5 "
                                required
                            />
                            <button
                                type="button"
                                onClick={togglePasswordVisibility}
                                className="absolute inset-y-0 right-0 flex items-center px-2"
                            >
                                {showPassword ? (
                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M19.8825 4.88134L19.1465 4.14539C18.9385 3.9374 18.5545 3.96941 18.3145 4.25736L15.7543 6.80132C14.6023 6.30538 13.3384 6.06538 12.0103 6.06538C8.05822 6.08132 4.63444 8.38529 2.98633 11.6975C2.8903 11.9055 2.8903 12.1614 2.98633 12.3374C3.75426 13.9054 4.90633 15.2015 6.34633 16.1774L4.25034 18.3054C4.01034 18.5454 3.97833 18.9293 4.13838 19.1374L4.87432 19.8733C5.08231 20.0813 5.4663 20.0493 5.7063 19.7613L19.7542 5.71345C20.0582 5.47358 20.0902 5.08962 19.8822 4.88161L19.8825 4.88134ZM12.8583 9.71322C12.5863 9.6492 12.2984 9.56925 12.0264 9.56925C10.6663 9.56925 9.57842 10.6573 9.57842 12.0172C9.57842 12.2892 9.64244 12.5771 9.72239 12.8492L8.65028 13.9052C8.33032 13.3452 8.15433 12.7211 8.15433 12.0172C8.15433 9.88924 9.86636 8.17722 11.9943 8.17722C12.6984 8.17722 13.3224 8.3532 13.8823 8.67316L12.8583 9.71322Z" fill="#666666" fill-opacity="0.8" />
                                        <path d="M21.0344 11.6974C20.4745 10.5774 19.7384 9.56945 18.8265 8.75342L15.8504 11.6974V12.0174C15.8504 14.1454 14.1384 15.8574 12.0104 15.8574H11.6905L9.80249 17.7454C10.5065 17.8893 11.2425 17.9854 11.9625 17.9854C15.9146 17.9854 19.3384 15.6814 20.9865 12.3532C21.1305 12.1292 21.1305 11.9053 21.0345 11.6973L21.0344 11.6974Z" fill="#666666" fill-opacity="0.8" />
                                    </svg>

                                ) : (
                                    <img width="19" height="19" src="https://img.icons8.com/material-rounded/24/666666/visible.png" alt="visible" />)}
                            </button>
                        </div>
                    </div>

                    <div className="mb-3 space-y-3 mt-7">
                        <p className="helper-text">By continuing, you agree to the <span className='underline terms'> <a href=""> Terms of use</a></span> and <span className='underline terms'> <a href=""> Privacy Policy.</a></span></p>
                        {/* <button className="w-full p-2 mt-5 text-white bg-gray-400 rounded-full poppins_button">Log In</button> */}
                        <button className="w-full p-2 mt-5 text-white rounded-full authActive-button poppins_button">Log In</button>
                    </div>

                    <div className="inline-flex items-center justify-center w-full mb-3">
                        <hr className="w-full h-px mt-5 mb-5 bg-gray-200 border-0 divider-or " />
                        <span className="absolute px-3 font-medium -translate-x-1/2 bg-white or left-1/2 ">OR</span>
                    </div>
                    <div className='grid grid-cols-2 mb-12 space-x-5'>
                        <button className="space-x-2 social-button">
                            <svg width="24" height="24" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <circle cx="16" cy="16" r="14" fill="#0C82EE" />
                                <path d="M21.2137 20.2816L21.8356 16.3301H17.9452V13.767C17.9452 12.6857 18.4877 11.6311 20.2302 11.6311H22V8.26699C22 8.26699 20.3945 8 18.8603 8C15.6548 8 13.5617 9.89294 13.5617 13.3184V16.3301H10V20.2816H13.5617V29.8345C14.2767 29.944 15.0082 30 15.7534 30C16.4986 30 17.2302 29.944 17.9452 29.8345V20.2816H21.2137Z" fill="white" />
                            </svg>
                            <p className='text-secondary'>Sign up with Facebook</p>
                        </button>
                        <button className="space-x-2 social-button">
                            <svg width="25" height="24" viewBox="0 0 25 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M23.001 12.2331C23.001 11.3698 22.9296 10.7398 22.7748 10.0864H12.7153V13.983H18.62C18.501 14.9514 17.8582 16.4097 16.4296 17.3897L16.4096 17.5202L19.5902 19.9349L19.8106 19.9564C21.8343 18.1247 23.001 15.4297 23.001 12.2331Z" fill="#4285F4" />
                                <path d="M12.714 22.5001C15.6068 22.5001 18.0353 21.5667 19.8092 19.9567L16.4282 17.39C15.5235 18.0083 14.3092 18.44 12.714 18.44C9.88069 18.44 7.47596 16.6083 6.61874 14.0767L6.49309 14.0871L3.18583 16.5955L3.14258 16.7133C4.90446 20.1433 8.5235 22.5001 12.714 22.5001Z" fill="#34A853" />
                                <path d="M6.62046 14.0767C6.39428 13.4234 6.26337 12.7233 6.26337 12C6.26337 11.2767 6.39428 10.5767 6.60856 9.92337L6.60257 9.78423L3.25386 7.2356L3.14429 7.28667C2.41814 8.71002 2.00146 10.3084 2.00146 12C2.00146 13.6917 2.41814 15.29 3.14429 16.7133L6.62046 14.0767Z" fill="#FBBC05" />
                                <path d="M12.7141 5.55997C14.7259 5.55997 16.083 6.41163 16.8569 7.12335L19.8807 4.23C18.0236 2.53834 15.6069 1.5 12.7141 1.5C8.52353 1.5 4.90447 3.85665 3.14258 7.28662L6.60686 9.92332C7.47598 7.39166 9.88073 5.55997 12.7141 5.55997Z" fill="#EB4335" />
                            </svg>

                            <p className='text-secondary'>Sign up with Google</p>
                        </button>
                    </div>
                    <div className='h-24'>

                    </div>
                </div>
            </div>
        </div>
    );
};

export default Login;
