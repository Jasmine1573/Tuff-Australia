import DashboardIcon from "../commons/icons/dashboardIcon";
import CategoryIcon from "../commons/icons/categoryIcon";
import FeedbackIcon from "../commons/icons/feedbackIcon";
import TicketIcon from "../commons/icons/ticketIcon";
import SettingIcon from "../commons/icons/settingIcon";
import { Link } from "react-router-dom";
import { NavLink,useLocation } from "react-router-dom";
import LogoutIcon from "../commons/icons/logoutIcon";

const Sidebar = () => {
    
    const location = useLocation();
    const { hash, pathname, search } = location;
console.log(pathname)

    const isActive = (path) => {
        return pathname==path
    }

    return (

        <>
            <nav className=" bg-gray-50 nav-border fixed top-0 z-50 w-full border-b border-[#E6552633]">
                <div className="px-3 py-3 lg:px-5 lg:pl-3">
                    <div className="flex items-center justify-between w-full">
                        <div className="flex items-center justify-start rtl:justify-end w-1/10">
                            <button data-drawer-target="logo-sidebar" data-drawer-toggle="logo-sidebar" aria-controls="logo-sidebar" type="button" className="inline-flex items-center p-2 text-sm text-gray-500 rounded-lg sm:hidden hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-gray-200 ">
                                <span className="sr-only">Open sidebar</span>
                                <svg className="w-6 h-6" aria-hidden="true" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                    <path clip-rule="evenodd" fill-rule="evenodd" d="M2 4.75A.75.75 0 012.75 4h14.5a.75.75 0 010 1.5H2.75A.75.75 0 012 4.75zm0 10.5a.75.75 0 01.75-.75h7.5a.75.75 0 010 1.5h-7.5a.75.75 0 01-.75-.75zM2 10a.75.75 0 01.75-.75h14.5a.75.75 0 010 1.5H2.75A.75.75 0 012 10z"></path>
                                </svg>
                            </button>
                            <a href="#" className="flex ms-2 md:me-24">
                                <img src="https://s3-alpha-sig.figma.com/img/c221/6f46/f274ab153ecf218b6916f5f4cb8fbf47?Expires=1710115200&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=HrkX4DCIJa17~H4mU7QYanN2jVsJip~D1Hg08j7KVIq04zxXXGnXgxhvis-vVVWNW7ImQHDHa0ClZc~79cFjattyPTJ8N2~Jbr0dPiT7ACTeVT44wEd9nXUlHyVIXnWJFpiNz82SzYiKqQaDvC6qN90nWhVREfR8~aHftLvptx5F1Kh4ql97eKm~HMLMm1rbhwkHW6dHP39ZnGlF2Apc-7Wypp2TqQ1Tfe8MtJNgqMedsqT5ttAqzHlEE2Db34ImhdWyK2YQ7UEPh30U1SF9l8LSuy4p19Msxl92VO9x6WaLZFWCVyQwXh5dBmBkwjLiajmK9MmigDZ5m3VhYxFC3w__" className="h-8 me-3" alt="FlowBite Logo" />
                                <span className="self-center text-xl font-semibold sm:text-2xl whitespace-nowrap ">TUFA</span>
                            </a>
                        </div>
                        <div className="flex items-center ">
                         
                            <div className="flex items-center ms-3">
                                <div className="">
                                    <button type="button" className="flex items-center space-x-3 text-sm rounded-full " aria-expanded="false" data-dropdown-toggle="dropdown-user">
                                        <img className="w-8 h-8 rounded-full" src="https://s3-alpha-sig.figma.com/img/ab12/3cea/787a6e2c2e87edda588ccfce54455c4b?Expires=1710115200&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=k~LPOejfKf0GSLqmfHzCbRJJTpLpp3ktzrCMleWwHPyk78Z~AJ9Ad~20BzrCz4Lgzv7uhpjVh5tC9CJjDPCsS1m~LkayPlvl0X5Lv8Z7GzP3F7lO~G6qfQzxv9hxY9bPiECBgrpO5R6xvF-XFnKPvbKQn7PlY5yXEbWnbA~1LuYVyyvzg3-QyTh99h7nwESOVvustAXQN9BWIFgnJWc1MreZ~PiPWcwpOTku6BgygYz-r71T~cmHOiTVL-uWB6SExDUejxP8aGJV1yOURI9oZ9peJTxZcHqO7Z3dVQV8Q0-QqQOAlFRaJRSSd9qCUq0vnl7Ztfj~vmUEvXgt-tSACA__" alt="user photo" />
                                        <div className="mr-8" >
                                            <p className="admin-name">Santosh</p>
                                            <p className="admin-role">Admin</p>
                                        </div>
                                    </button>
                                </div>
                                <div className="z-50 hidden my-4 text-base list-none bg-white divide-y divide-gray-100 rounded shadow " id="dropdown-user">
                                    <div className="px-4 py-3" role="none">
                                        <p className="text-sm text-gray-900 " role="none">
                                            Santosh Pandit
                                        </p>
                                        <p className="text-sm font-medium text-gray-900 truncate " role="none">
                                            skpandit659@gmail.com
                                        </p>
                                    </div>
                                    <ul className="py-1" role="none">
                                        <li>
                                            <a href="#" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 " role="menuitem">Dashboard</a>
                                        </li>
                                        <li>
                                            <a href="#" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 " role="menuitem">Settings</a>
                                        </li>
                                      
                                        <li>
                                            <a href="#" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 " role="menuitem">Sign out</a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </nav>

            <aside style={{ zIndex:1000 }} id="logo-sidebar" className="bg-gray-50 sidebar-border fixed top-0 left-0 z-100 w-64 h-screen pt-5 transition-transform -translate-x-full  border-r border-[#E6552633] sm:translate-x-0" aria-label="Sidebar">
                <div className="h-full pb-4 overflow-y-auto ">
                    <div className="flex items-center justify-center p-3">
                       <img src="https://s3-alpha-sig.figma.com/img/c221/6f46/f274ab153ecf218b6916f5f4cb8fbf47?Expires=1710115200&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=HrkX4DCIJa17~H4mU7QYanN2jVsJip~D1Hg08j7KVIq04zxXXGnXgxhvis-vVVWNW7ImQHDHa0ClZc~79cFjattyPTJ8N2~Jbr0dPiT7ACTeVT44wEd9nXUlHyVIXnWJFpiNz82SzYiKqQaDvC6qN90nWhVREfR8~aHftLvptx5F1Kh4ql97eKm~HMLMm1rbhwkHW6dHP39ZnGlF2Apc-7Wypp2TqQ1Tfe8MtJNgqMedsqT5ttAqzHlEE2Db34ImhdWyK2YQ7UEPh30U1SF9l8LSuy4p19Msxl92VO9x6WaLZFWCVyQwXh5dBmBkwjLiajmK9MmigDZ5m3VhYxFC3w__" className="h-16 me-3" alt="FlowBite Logo" />

                    </div>

                    <ul className="mt-5 font-medium">
                        <li style={{ backgroundColor: isActive('/dashboard')? '#E65526':'white' }} className="p-2">
                            <Link to="/dashboard">
                                <a href="#" className={`flex items-center p-2 ${isActive('/dashboard')?'text-white':'text-gray-700'}  rounded-lg group`}>
                                    <DashboardIcon color={isActive('/dashboard') ? 'white' :'#E65526'} />
                                    <span className="ms-3 sidebar-list-item">Dashboard</span>
                                </a>
                          </Link>
                        </li>

                        <li style={{ backgroundColor: isActive('/dashboard/categories') ? '#E65526' : 'white' }} className="p-2">
                            <Link to="/dashboard/categories">
                                <a href="#" className={`flex items-center p-2 ${isActive('/dashboard/categories') ? 'text-white' : 'text-gray-700'}  rounded-lg group`}>
                                    <CategoryIcon color={isActive('/dashboard/categories') ? 'white' : '#E65526'} />
                                    <span className="ms-3 sidebar-list-item">Categories</span>
                                </a>
                            </Link>
                        </li>
                        
                        <li style={{ backgroundColor: isActive('/dashboard/feedbacks') ? '#E65526' : 'white' }} className="p-2">
                            <Link to="/dashboard/feedbacks">
                                <a href="#" className={`flex items-center p-2 ${isActive('/dashboard/feedbacks') ? 'text-white' : 'text-gray-700'}  rounded-lg group`}>
                                    <FeedbackIcon color={isActive('/dashboard/feedbacks') ? 'white' : '#E65526'} />
                                    <span className="ms-3 sidebar-list-item">Feedbacks</span>
                                </a>
                            </Link>
                        </li>

                        <li style={{ backgroundColor: isActive('/dashboard/tickets') ? '#E65526' : 'white' }} className="p-2">
                            <Link to="/dashboard/tickets">
                                <a href="#" className={`flex items-center p-2 ${isActive('/dashboard/tickets') ? 'text-white' : 'text-gray-700'}  rounded-lg group`}>
                                    <TicketIcon color={isActive('/dashboard/tickets') ? 'white' : '#E65526'} />
                                    <span className="ms-3 sidebar-list-item">Tickets</span>
                                </a>
                            </Link>
                        </li>

                        <li style={{ backgroundColor: isActive('/dashboard/settings') ? '#E65526' : 'white' }} className="p-2">
                            <Link to="/dashboard/settings">
                                <a href="#" className={`flex items-center p-2 ${isActive('/dashboard/settings') ? 'text-white' : 'text-gray-700'}  rounded-lg group`}>
                                    <SettingIcon color={isActive('/dashboard/settings') ? 'white' : '#E65526'} />
                                    <span className="ms-3 sidebar-list-item">Settings</span>
                                </a>
                            </Link>
                        </li>


                        <li style={{ backgroundColor: isActive('/dashboard/settings') ? '#E65526' : 'white' }} className="p-2">
                            <a href="#" className={`flex items-center p-2 ${isActive('/dashboard/settings') ? 'text-white' : 'text-gray-700'}  rounded-lg group`}>
                                <LogoutIcon />
                                <span className="ms-3 sidebar-list-item">Logout</span>
                                </a>
                        </li>
                    </ul>

                </div>
            </aside>

          
        </>


    );
}
export default Sidebar