const Header = () => {
    return (
        <>
           
            <nav className="fixed top-0 z-20 w-full bg-white border-b border-gray-200 start-0">
                <div className="flex flex-row items-center justify-around p-2 bg-gray-900 subnav nav-pad">
                    <div className="flex items-center space-x-2 ">
                        <svg width="12" height="14" viewBox="0 0 12 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M11.7467 4.63341C11.0467 1.55341 8.36006 0.166748 6.00006 0.166748C6.00006 0.166748 6.00006 0.166748 5.9934 0.166748C3.64006 0.166748 0.94673 1.54675 0.24673 4.62675C-0.53327 8.06675 1.5734 10.9801 3.48006 12.8134C4.18673 13.4934 5.0934 13.8334 6.00006 13.8334C6.90673 13.8334 7.8134 13.4934 8.5134 12.8134C10.4201 10.9801 12.5267 8.07341 11.7467 4.63341ZM6.00006 7.97341C4.84006 7.97341 3.90006 7.03342 3.90006 5.87341C3.90006 4.71342 4.84006 3.77341 6.00006 3.77341C7.16006 3.77341 8.10006 4.71342 8.10006 5.87341C8.10006 7.03342 7.16006 7.97341 6.00006 7.97341Z" fill="white" />
                        </svg>

                        <p className="text-white">Tuff Stores</p>
                    </div>
                    <div className="flex items-center space-x-2">
                        <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M10.6663 1.3335H5.33301C2.66634 1.3335 1.33301 2.66683 1.33301 5.3335V14.0002C1.33301 14.3668 1.63301 14.6668 1.99967 14.6668H10.6663C13.333 14.6668 14.6663 13.3335 14.6663 10.6668V5.3335C14.6663 2.66683 13.333 1.3335 10.6663 1.3335ZM9.33301 10.1668H4.66634C4.39301 10.1668 4.16634 9.94016 4.16634 9.66683C4.16634 9.3935 4.39301 9.16683 4.66634 9.16683H9.33301C9.60634 9.16683 9.83301 9.3935 9.83301 9.66683C9.83301 9.94016 9.60634 10.1668 9.33301 10.1668ZM11.333 6.8335H4.66634C4.39301 6.8335 4.16634 6.60683 4.16634 6.3335C4.16634 6.06016 4.39301 5.8335 4.66634 5.8335H11.333C11.6063 5.8335 11.833 6.06016 11.833 6.3335C11.833 6.60683 11.6063 6.8335 11.333 6.8335Z" fill="white" />
                        </svg>

                        <p className="text-white">Tuff News</p>
                    </div>
                </div>
                <div className="flex flex-wrap items-center justify-between p-4 mx-auto nav-pad">
                    <a href="#" className="flex items-center space-x-3 rtl:space-x-reverse">
                        <img src="https://s3-alpha-sig.figma.com/img/c221/6f46/f274ab153ecf218b6916f5f4cb8fbf47?Expires=1710115200&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=HrkX4DCIJa17~H4mU7QYanN2jVsJip~D1Hg08j7KVIq04zxXXGnXgxhvis-vVVWNW7ImQHDHa0ClZc~79cFjattyPTJ8N2~Jbr0dPiT7ACTeVT44wEd9nXUlHyVIXnWJFpiNz82SzYiKqQaDvC6qN90nWhVREfR8~aHftLvptx5F1Kh4ql97eKm~HMLMm1rbhwkHW6dHP39ZnGlF2Apc-7Wypp2TqQ1Tfe8MtJNgqMedsqT5ttAqzHlEE2Db34ImhdWyK2YQ7UEPh30U1SF9l8LSuy4p19Msxl92VO9x6WaLZFWCVyQwXh5dBmBkwjLiajmK9MmigDZ5m3VhYxFC3w__" className="h-16" alt="TUFF Logo" />
                    </a>
                    <div className="flex space-x-3 md:order-2 md:space-x-0 rtl:space-x-reverse">
                        <button data-collapse-toggle="navbar-sticky" type="button" className="inline-flex items-center justify-center w-10 h-10 p-2 text-sm text-gray-500 rounded-lg md:hidden focus:outline-none focus:ring-2 focus:ring-gray-200 dark:text-gray-400 " aria-controls="navbar-sticky" aria-expanded="false">
                            <span className="sr-only">Open main menu</span>
                            <svg className="w-5 h-5" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 17 14">
                                <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M1 1h15M1 7h15M1 13h15" />
                            </svg>
                        </button>
                    </div>
                    <div className="items-center justify-between hidden w-full md:flex md:w-auto md:order-1" id="navbar-sticky">
                        <ul className="flex flex-col p-4 mt-4 font-medium border border-gray-100 rounded-lg md:p-0 md:space-x-8 rtl:space-x-reverse md:flex-row md:mt-0 md:border-0 md:bg-white">

                            <li>
                                <a href="#" className="nav-li">Bullbars</a>
                            </li>
                            <li>
                                <a href="#" className="nav-li">Suspension</a>
                            </li>
                            <li>
                                <a href="#" className="nav-li">Trays & Canopies</a>
                            </li>
                            <li>
                                <a href="#" className="nav-li">About Us</a>
                            </li>
                            <li>
                                <a href="#" className="nav-li">Shop</a>
                            </li>
                            <li>
                                <a href="#" className="nav-li">Contact Us</a>
                            </li>


                        </ul>
                    </div>
                </div>
            </nav>
        </>

    );
}
export default Header;