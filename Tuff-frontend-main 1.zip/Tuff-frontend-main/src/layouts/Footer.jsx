const Footer = () => {
    return (
        // <div className="grid items-center justify-between grid-flow-row-dense grid-cols-4 py-8 footer nav-pad">
        //     <a href="#" className="flex items-center space-x-3 rtl:space-x-reverse">
        //         <img src="https://s3-alpha-sig.figma.com/img/c221/6f46/f274ab153ecf218b6916f5f4cb8fbf47?Expires=1710115200&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=HrkX4DCIJa17~H4mU7QYanN2jVsJip~D1Hg08j7KVIq04zxXXGnXgxhvis-vVVWNW7ImQHDHa0ClZc~79cFjattyPTJ8N2~Jbr0dPiT7ACTeVT44wEd9nXUlHyVIXnWJFpiNz82SzYiKqQaDvC6qN90nWhVREfR8~aHftLvptx5F1Kh4ql97eKm~HMLMm1rbhwkHW6dHP39ZnGlF2Apc-7Wypp2TqQ1Tfe8MtJNgqMedsqT5ttAqzHlEE2Db34ImhdWyK2YQ7UEPh30U1SF9l8LSuy4p19Msxl92VO9x6WaLZFWCVyQwXh5dBmBkwjLiajmK9MmigDZ5m3VhYxFC3w__" className="h-16" alt="TUFF Logo" />
        //     </a>
        //     <div className="col-span-3" >
        //         <ul className="grid grid-cols-6 font-medium rounded-lg rtl:space-x-reverse">

        //             <li>
        //                 <a href="#" className="footer-li">Bullbars</a>
        //             </li>
        //             <li>
        //                 <a href="#" className="footer-li">Suspension</a>
        //             </li>
        //             <li className="">
        //                 <a href="#" className="footer-li">Trays & Canopies</a>
        //             </li>
        //             <li>
        //                 <a href="#" className="footer-li">About Us</a>
        //             </li>
        //             <li>
        //                 <a href="#" className="footer-li">Shop</a>
        //             </li>
        //             <li>
        //                 <a href="#" className="footer-li">Contact Us</a>
        //             </li>


        //         </ul>
        //         <div className="footer-sub-content">
        //             <p>© All Rights Reserved 2023. Licensing</p>
        //             <p>Designed and Developed</p>
        //         </div>
        //     </div>
        // </div>


        <footer className="py-8 bg-gray-900">
            <div className="w-full max-w-screen-xl p-4 mx-auto md:py-8">
                <div className="sm:flex sm:items-center sm:justify-between">
                    <a href="https://flowbite.com/" className="flex items-center mb-4 space-x-3 sm:mb-0 rtl:space-x-reverse">
                        <img src="https://s3-alpha-sig.figma.com/img/c221/6f46/f274ab153ecf218b6916f5f4cb8fbf47?Expires=1710115200&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=HrkX4DCIJa17~H4mU7QYanN2jVsJip~D1Hg08j7KVIq04zxXXGnXgxhvis-vVVWNW7ImQHDHa0ClZc~79cFjattyPTJ8N2~Jbr0dPiT7ACTeVT44wEd9nXUlHyVIXnWJFpiNz82SzYiKqQaDvC6qN90nWhVREfR8~aHftLvptx5F1Kh4ql97eKm~HMLMm1rbhwkHW6dHP39ZnGlF2Apc-7Wypp2TqQ1Tfe8MtJNgqMedsqT5ttAqzHlEE2Db34ImhdWyK2YQ7UEPh30U1SF9l8LSuy4p19Msxl92VO9x6WaLZFWCVyQwXh5dBmBkwjLiajmK9MmigDZ5m3VhYxFC3w__" className="h-16" alt="Flowbite Logo" />
                    </a>
                    <ul className="flex flex-wrap items-center mb-6 text-sm font-medium text-gray-500 sm:mb-0 dark:text-gray-400">
                        <li>
                            <a href="#" className="hover:underline me-4 md:me-6 footer-li">Bullbars</a>
                        </li>
                        <li>
                            <a href="#" className="hover:underline me-4 md:me-6 footer-li">Suspension</a>
                        </li>
                        <li>
                            <a href="#" className="hover:underline me-4 md:me-6 footer-li">Trays & Canopies</a>
                        </li>
                        <li>
                            <a href="#" className="hover:underline me-4 md:me-6 footer-li">About Us</a>
                        </li>
                        <li>
                            <a href="#" className="hover:underline me-4 md:me-6 footer-li">Shop</a>
                        </li>
                        <li>
                            <a href="#" className="hover:underline footer-li">Contact Us</a>
                        </li>
                    </ul>
                </div>
                <span className="block mt-5 text-sm text-gray-500 sm:text-center dark:text-gray-400"> <a href="https://flowbite.com/" className="hover:underline"></a>Copyright ©TUFF AUSTRALIA 2023. All Rights Reserved</span>
            </div>
        </footer>


    );
}
export default Footer