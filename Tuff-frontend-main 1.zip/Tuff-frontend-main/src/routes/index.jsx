import {createBrowserRouter} from "react-router-dom";

import Dashboard from "../pages/dashboard";
import Home from "../pages/dashboard/Home";
import Category from "../pages/dashboard/categories";
import Feedback from "../pages/dashboard/feedbacks";
import Ticket from "../pages/dashboard/tickets";
import Login from "../pages/Login";
import Register from "../pages/Register";
import UserHome from "../pages/Home";
import UserFeedback from "../pages/Home/feedback";
const router = createBrowserRouter([
    {
        path: "/",
        element: <UserHome />,
        children: [
            {
                path: "",
                element:<UserFeedback/>
            }
        ]
    },
    {
        path: "/login",
        element:<Login/>,
    },
    {
        path: "/register",
        element:<Register/>,
    },
    {
        path: "/feedback",
        element:<Register/>,
    },
    {
        path: "dashboard",
        element: <Dashboard />,
        children: [
            {
                path: "",
                element: <Home/>
            },
            {
                path: "categories",
                element: <Category/>

            },
            {
                path: "feedbacks",
                element: <Feedback />

            },
            {
                path: "tickets",
                element: <Ticket />

            }
        ]
    },
]);
export default router;