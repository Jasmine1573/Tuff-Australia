// import userApiService from "../../services/userApiService";
import { createAsyncThunk } from '@reduxjs/toolkit'

export const getProfile = createAsyncThunk(
    'user/getProfile',
    async () => {
        // try {
        //     const response = await userApiService.profile();
        //     return response.data.data
        // } catch (error) {
        //     console.log("error user profile", error)
        // }
    },
)