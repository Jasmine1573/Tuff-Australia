import { createSlice } from "@reduxjs/toolkit";
import initialState from "./states";
import reducers from "./reducers";
import extraReducers from "./extraReducers";

export const userSlice = createSlice({

    name: "user",
    initialState,
    reducers,
    extraReducers
});

export const { test } = userSlice.actions;

export default userSlice.reducer;