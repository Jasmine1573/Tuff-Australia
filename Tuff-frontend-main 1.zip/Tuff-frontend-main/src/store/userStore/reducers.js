// import userApiService from "../../services/userApiService";

const reducers = {

    async test(state, action) {

        // console.log({ response })
        // state.profile = response?.data?.data;

    }

};
export default reducers;