const initialState = {

    profile: null

}
export default initialState;