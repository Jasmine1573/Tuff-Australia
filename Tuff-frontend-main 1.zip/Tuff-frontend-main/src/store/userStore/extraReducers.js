import { getProfile } from "./actions";

const extraReducers = (builder) => {
    builder.addCase(getProfile.fulfilled, (state, action) => {
        state.profile = action.payload;
    });
}
export default extraReducers