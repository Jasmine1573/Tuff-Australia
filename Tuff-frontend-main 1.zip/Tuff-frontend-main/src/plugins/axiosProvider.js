import axios from "axios";

export const baseURL = import.meta.env.VITE_HOST_URL;

const instance = axios.create({
    baseURL: `${baseURL}/api/`,
    //   timeout: 100000,
    headers: {
        common: {
            "X-Requested-With": "XMLHttpRequest",
            "Access-Control-Allow-Origin": "*",
        },
        Accept: "application/json",
    },
});

instance.interceptors.request.use(
    (config) => {
        const authToken = JSON.parse(localStorage.getItem("auth-token"));
        if (authToken && authToken.id) {
            config.headers.Authorization = `Bearer ${authToken.id}`;
        }
        return config;
    },
    (error) => {
        return Promise.reject(error);
    }
);

instance.interceptors.response.use(
    (response) => response,
    (error) => {
        if (error?.response?.status == 401) {
            localStorage.removeItem("auth-token");
            localStorage.removeItem("auth-user");
            window.location.href = import.meta.env.VITE_BASE_URL + "/login";
        }
        return Promise.reject(error);
    }
);

export default instance;