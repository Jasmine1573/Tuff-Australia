const Pagination = () => {
    return (
        <div className="flex items-center justify-between w-full p-2 my-2">
            <div>
                <p className="pagination-result">Showing 1-09 of 78</p>
            </div>
            <nav aria-label="Page navigation example">
                <ul className="flex h-10 -space-x-px text-base">
                    <li>
                        <a href="#" className="flex items-center justify-center h-full px-4 leading-tight text-gray-500 bg-white border border-gray-300 rounded-l-lg hover:bg-gray-100 hover:text-gray-700 dark:bg-gray-800 dark:border-gray-700 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-white">
                            &lt; Previous
                        </a>
                    </li>
                    <li>
                        <a href="#" className="flex items-center justify-center h-full px-4 leading-tight text-gray-500 bg-white border border-gray-300 rounded-r-lg hover:bg-gray-100 hover:text-gray-700 dark:bg-gray-800 dark:border-gray-700 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-white">
                            Next &gt;
                        </a>
                    </li>
                </ul>
            </nav>

        </div>
    );
}
export default Pagination